Solgema.FlowView
================

Overview
--------

Solgema.FlowView eases the use of jquerytool tabs, panes, scrollable, navigator.
The FlowView will take items in a folder or a collection and display them as panes, scrollable, ...


Usage
-----


Go to a folder or a collection and sets the Display to FlowView.
A new tab will appear with the flowview settings.
You will be able to specify the transition effet, duration, etc.


Compatibility
-------------

Should work with both Plone 4 and Plone 5.
