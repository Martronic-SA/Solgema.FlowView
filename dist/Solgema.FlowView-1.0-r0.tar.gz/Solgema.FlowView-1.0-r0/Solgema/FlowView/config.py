PROJECTNAME = "Solgema.FlowView"

DISPLAY_NAME_VIEW_PREFIX = 'flowview-'

from zope.i18nmessageid import MessageFactory
_ = MessageFactory("Solgema.FlowView")
