Changelog for Solgema.FlowView

- 1.0.2 : Fix missing file in dx directory (Plone 5 Dexterity) [fmoret]

- 1.0.1 : Python version

Solgema.FlowView - 0.1 Unreleased

    - Initial package structure.
      [zopeskel]

