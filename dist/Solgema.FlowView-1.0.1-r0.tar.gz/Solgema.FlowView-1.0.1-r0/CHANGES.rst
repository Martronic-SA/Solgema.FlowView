Changelog for Solgema.FlowView

    (name of developer listed in brackets)

Solgema.FlowView - 0.1 Unreleased

    - Initial package structure.
      [zopeskel]

