from zope.interface import Interface, Attribute

class IFlowViewMarkerDX(Interface):
    """
    marker interface for content types that implement
    the flowview
    """
